# SecureGuard Pro - Professional Security Services Website

## Overview

SecureGuard Pro is a full-stack web application for a professional security services company. The application serves as a business website showcasing security services including event security, corporate security, CCTV monitoring, residential security, personal protection, and security consulting. The site features a modern design with a contact form system that allows potential clients to inquire about services and request quotes.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript using Vite as the build tool and development server. The application follows a modern React pattern with functional components and hooks.

**UI System**: Built on shadcn/ui component library with Radix UI primitives for accessibility and Tailwind CSS for styling. The design system uses CSS variables for theming with support for light/dark mode variants.

**Routing**: Uses Wouter for client-side routing, providing a lightweight alternative to React Router with a simple API for navigation between pages.

**State Management**: TanStack Query (React Query) handles server state management, caching, and API interactions. Local component state is managed with React hooks.

**Form Handling**: React Hook Form with Zod validation for type-safe form validation and submission, particularly for the contact form functionality.

**Directory Structure**:
- `/client/src/components/ui/` - Reusable UI components from shadcn/ui
- `/client/src/components/layout/` - Layout components (navbar, footer)
- `/client/src/components/sections/` - Page sections (hero, services, team, contact)
- `/client/src/pages/` - Route-level page components
- `/client/src/hooks/` - Custom React hooks
- `/client/src/lib/` - Utility functions and configurations

### Backend Architecture

**Framework**: Express.js server with TypeScript, configured as an ESM module for modern JavaScript features.

**API Design**: RESTful API endpoints under `/api` prefix with proper HTTP status codes and JSON responses. Currently implements contact form submission and message retrieval endpoints.

**Data Storage**: Dual storage approach with in-memory storage (MemStorage) for development and Drizzle ORM configured for PostgreSQL production use. The storage interface abstraction allows easy switching between implementations.

**Validation**: Zod schemas shared between frontend and backend ensure consistent data validation across the application stack.

**Development Setup**: Integrated Vite development server with HMR support and middleware for serving the React application in development mode.

### Data Layer

**Database**: PostgreSQL configured through Drizzle ORM with migrations support. Schema includes users table for future authentication and contact_messages table for form submissions.

**Schema Design**: Type-safe database schemas using Drizzle with automatic TypeScript type inference. Validation schemas using drizzle-zod for seamless integration with Zod validation.

**Migration System**: Drizzle Kit handles database migrations with schema changes tracked in the `/migrations` directory.

### Security & Performance

**Type Safety**: Full TypeScript coverage across frontend, backend, and shared code with strict configuration for compile-time error detection.

**Validation**: Client and server-side validation using shared Zod schemas prevents invalid data submission and ensures data integrity.

**Error Handling**: Comprehensive error handling with proper HTTP status codes, user-friendly error messages, and development error overlays.

**Build Optimization**: Vite handles frontend bundling with tree-shaking and code splitting. ESBuild compiles the Node.js server for production deployment.

## External Dependencies

### Database Services
- **PostgreSQL**: Primary database using Neon Database serverless PostgreSQL for production hosting
- **Drizzle ORM**: Type-safe database ORM with PostgreSQL dialect support

### UI Component Libraries
- **Radix UI**: Headless, accessible component primitives for building the design system
- **shadcn/ui**: Pre-built component library built on Radix UI with Tailwind styling
- **Lucide React**: Icon library providing consistent iconography
- **React Icons**: Additional icon sets including social media icons

### Development Tools
- **Vite**: Frontend build tool and development server with React plugin
- **TypeScript**: Type checking and compilation for both frontend and backend
- **Tailwind CSS**: Utility-first CSS framework with PostCSS processing
- **ESBuild**: Fast JavaScript bundler for server-side code compilation

### State Management & API
- **TanStack Query**: Server state management with caching, background updates, and error handling
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Runtime type validation and schema definition
- **Wouter**: Lightweight client-side routing

### Hosting & Deployment
- **Replit**: Development environment and hosting platform with integrated deployment
- **Neon Database**: Serverless PostgreSQL hosting with automatic scaling