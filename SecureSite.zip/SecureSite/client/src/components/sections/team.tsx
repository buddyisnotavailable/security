const teamMembers = [
  {
    id: "michael-rodriguez",
    name: "Michael Rodriguez",
    position: "Chief Security Officer",
    bio: "Former police captain with 15 years of law enforcement experience. Specializes in corporate security and emergency response planning.",
    credential: "Certified Protection Professional",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
  },
  {
    id: "sarah-chen",
    name: "Sarah Chen",
    position: "Operations Manager",
    bio: "Military veteran with expertise in surveillance systems and threat assessment. Leads our technology integration and training programs.",
    credential: "Security Systems Specialist",
    image: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
  },
  {
    id: "david-thompson",
    name: "David Thompson",
    position: "Field Supervisor",
    bio: "Experienced field supervisor with specialization in event security and crowd management. Coordinates on-site operations and emergency protocols.",
    credential: "Event Security Certified",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
  },
  {
    id: "lisa-martinez",
    name: "Lisa Martinez",
    position: "Technical Specialist",
    bio: "CCTV and alarm systems expert with 10 years in security technology. Handles installation, maintenance, and monitoring system optimization.",
    credential: "Security Tech Certified",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
  },
  {
    id: "james-wilson",
    name: "James Wilson",
    position: "Security Consultant",
    bio: "Risk assessment specialist with extensive corporate security background. Provides strategic security planning and vulnerability assessments.",
    credential: "Risk Management Expert",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
  },
  {
    id: "rachel-kim",
    name: "Rachel Kim",
    position: "Training Coordinator",
    bio: "Former federal agent specializing in security training and protocol development. Ensures all team members meet highest professional standards.",
    credential: "Federal Training Certified",
    image: "https://images.unsplash.com/photo-1551836022-deb4988cc6c0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
  }
];

export function Team() {
  return (
    <section id="team" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="team-title">
            Meet Our Team
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="team-description">
            Our experienced security professionals bring decades of combined expertise 
            in law enforcement, military service, and private security.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teamMembers.map((member) => (
            <div
              key={member.id}
              className="bg-card border border-border rounded-xl p-8 text-center hover:shadow-lg transition-shadow"
              data-testid={`team-member-${member.id}`}
            >
              <img
                src={member.image}
                alt={`${member.name} - ${member.position}`}
                className="w-32 h-32 rounded-full mx-auto mb-6 object-cover border-4 border-primary/10"
                data-testid={`member-photo-${member.id}`}
              />
              <h3 className="text-xl font-semibold text-foreground mb-2" data-testid={`member-name-${member.id}`}>
                {member.name}
              </h3>
              <p className="text-primary font-medium mb-4" data-testid={`member-position-${member.id}`}>
                {member.position}
              </p>
              <p className="text-muted-foreground text-sm mb-4" data-testid={`member-bio-${member.id}`}>
                {member.bio}
              </p>
              <div className="flex justify-center">
                <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-medium" data-testid={`member-credential-${member.id}`}>
                  {member.credential}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
