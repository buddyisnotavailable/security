import { Users, Building, Video, Home, ShieldQuestion, Settings } from "lucide-react";

const services = [
  {
    id: "event-security",
    icon: Users,
    title: "Event Security",
    description: "Professional security personnel for concerts, conferences, weddings, and private events. Crowd control, access management, and emergency response.",
    features: ["Trained security officers", "Crowd management", "Emergency protocols"]
  },
  {
    id: "corporate-security",
    icon: Building,
    title: "Corporate Security",
    description: "Comprehensive security solutions for offices, warehouses, and commercial properties. 24/7 monitoring, access control, and asset protection.",
    features: ["24/7 surveillance", "Access control systems", "Asset protection"]
  },
  {
    id: "cctv-monitoring",
    icon: Video,
    title: "CCTV Monitoring",
    description: "Advanced video surveillance systems with remote monitoring capabilities. Real-time alerts, recorded footage, and comprehensive security coverage.",
    features: ["HD camera systems", "Remote monitoring", "Real-time alerts"]
  },
  {
    id: "residential-security",
    icon: Home,
    title: "Residential Security",
    description: "Protect your home and family with personalized residential security solutions. Alarm systems, patrol services, and emergency response.",
    features: ["Alarm systems", "Mobile patrols", "Emergency response"]
  },
  {
    id: "personal-protection",
    icon: ShieldQuestion,
    title: "Personal Protection",
    description: "Executive protection and personal security services for high-profile individuals. Discreet, professional, and highly trained security personnel.",
    features: ["Executive protection", "Threat assessment", "Discreet service"]
  },
  {
    id: "security-consulting",
    icon: Settings,
    title: "Security Consulting",
    description: "Professional security assessments and consulting services. Risk analysis, security planning, and custom security solutions.",
    features: ["Risk assessment", "Security planning", "Custom solutions"]
  }
];

export function Services() {
  return (
    <section id="services" className="py-20 bg-card">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="services-title">
            Our Security Services
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="services-description">
            Comprehensive security solutions tailored to your specific needs, 
            delivered by experienced professionals with cutting-edge technology.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="bg-background border border-border rounded-xl p-8 hover:shadow-lg transition-all duration-300 group"
                data-testid={`service-card-${service.id}`}
              >
                <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <Icon className="text-primary text-2xl" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4" data-testid={`service-title-${service.id}`}>
                  {service.title}
                </h3>
                <p className="text-muted-foreground mb-6" data-testid={`service-description-${service.id}`}>
                  {service.description}
                </p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mr-3 flex-shrink-0"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
