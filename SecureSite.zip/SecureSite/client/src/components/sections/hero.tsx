import { Button } from "@/components/ui/button";

export function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="bg-gradient-to-br from-primary/5 to-secondary/10 py-20 lg:py-32">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight">
              Professional Security Services You Can{" "}
              <span className="text-primary">Trust</span>
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Protecting what matters most with comprehensive security solutions. 
              From event security to corporate protection, we deliver peace of mind 
              through expert service and cutting-edge technology.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => scrollToSection('contact')}
                className="bg-primary text-primary-foreground px-8 py-4 rounded-lg font-semibold hover:bg-primary/90 transition-colors"
                data-testid="button-get-quote"
              >
                Get Free Quote
              </Button>
              <Button
                variant="outline"
                onClick={() => scrollToSection('services')}
                className="border border-border text-foreground px-8 py-4 rounded-lg font-semibold hover:bg-accent transition-colors"
                data-testid="button-learn-more"
              >
                Learn More
              </Button>
            </div>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
              alt="Professional security team in modern office building"
              className="rounded-2xl shadow-2xl w-full h-auto"
              data-testid="hero-image"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-2xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
