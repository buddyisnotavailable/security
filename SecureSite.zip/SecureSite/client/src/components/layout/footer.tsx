import { Shield } from "lucide-react";
import { SiFacebook, SiLinkedin, SiInstagram, SiX } from "react-icons/si";

export function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-foreground text-primary-foreground py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Shield className="text-primary-foreground text-xl" />
              </div>
              <span className="text-xl font-bold">SecureGuard Pro</span>
            </div>
            <p className="text-primary-foreground/80 mb-6 max-w-md" data-testid="footer-description">
              Professional security services you can trust. Protecting what matters most 
              with comprehensive security solutions and expert service.
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center text-primary-foreground hover:bg-primary transition-colors"
                data-testid="footer-social-facebook"
              >
                <SiFacebook />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center text-primary-foreground hover:bg-primary transition-colors"
                data-testid="footer-social-linkedin"
              >
                <SiLinkedin />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center text-primary-foreground hover:bg-primary transition-colors"
                data-testid="footer-social-instagram"
              >
                <SiInstagram />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center text-primary-foreground hover:bg-primary transition-colors"
                data-testid="footer-social-x"
              >
                <SiX />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => scrollToSection('home')}
                  className="text-primary-foreground/80 hover:text-primary-foreground transition-colors text-left"
                  data-testid="footer-link-home"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('services')}
                  className="text-primary-foreground/80 hover:text-primary-foreground transition-colors text-left"
                  data-testid="footer-link-services"
                >
                  Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('team')}
                  className="text-primary-foreground/80 hover:text-primary-foreground transition-colors text-left"
                  data-testid="footer-link-team"
                >
                  Team
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection('contact')}
                  className="text-primary-foreground/80 hover:text-primary-foreground transition-colors text-left"
                  data-testid="footer-link-contact"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-semibold mb-4">Contact Info</h3>
            <div className="space-y-3 text-primary-foreground/80">
              <p data-testid="footer-phone">
                <i className="fas fa-phone mr-2"></i> (123) 456-7890
              </p>
              <p data-testid="footer-email">
                <i className="fas fa-envelope mr-2"></i> info@secureguardpro.com
              </p>
              <p data-testid="footer-address">
                <i className="fas fa-map-marker-alt mr-2"></i> 1234 Security Plaza
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center">
          <p className="text-primary-foreground/60" data-testid="footer-copyright">
            © 2024 SecureGuard Pro. All rights reserved. | Privacy Policy | Terms of Service
          </p>
        </div>
      </div>
    </footer>
  );
}
