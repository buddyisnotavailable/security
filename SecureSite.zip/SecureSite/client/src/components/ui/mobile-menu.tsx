import { SiFacebook, SiLinkedin, SiInstagram } from "react-icons/si";

interface MobileMenuProps {
  isOpen: boolean;
  onNavigate: (id: string) => void;
}

export function MobileMenu({ isOpen, onNavigate }: MobileMenuProps) {
  if (!isOpen) return null;

  return (
    <div className="md:hidden mt-4 pb-4 border-t border-border pt-4" data-testid="mobile-menu">
      <div className="flex flex-col space-y-3">
        <button
          onClick={() => onNavigate('home')}
          className="text-foreground hover:text-primary transition-colors font-medium text-left"
          data-testid="mobile-nav-home"
        >
          Home
        </button>
        <button
          onClick={() => onNavigate('services')}
          className="text-muted-foreground hover:text-primary transition-colors font-medium text-left"
          data-testid="mobile-nav-services"
        >
          Services
        </button>
        <button
          onClick={() => onNavigate('team')}
          className="text-muted-foreground hover:text-primary transition-colors font-medium text-left"
          data-testid="mobile-nav-team"
        >
          Team
        </button>
        <button
          onClick={() => onNavigate('contact')}
          className="text-muted-foreground hover:text-primary transition-colors font-medium text-left"
          data-testid="mobile-nav-contact"
        >
          Contact
        </button>
        <div className="flex space-x-4 pt-2">
          <a
            href="#"
            className="text-muted-foreground hover:text-primary transition-colors"
            data-testid="mobile-social-facebook"
          >
            <SiFacebook className="w-4 h-4" />
          </a>
          <a
            href="#"
            className="text-muted-foreground hover:text-primary transition-colors"
            data-testid="mobile-social-linkedin"
          >
            <SiLinkedin className="w-4 h-4" />
          </a>
          <a
            href="#"
            className="text-muted-foreground hover:text-primary transition-colors"
            data-testid="mobile-social-instagram"
          >
            <SiInstagram className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
}
